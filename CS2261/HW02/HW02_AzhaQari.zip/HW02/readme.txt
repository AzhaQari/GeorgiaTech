-The objective of this game is to collect 5 green rectangles ("good" rectangles) consecutively
with your Player Rectangle (Cyan) without colliding with a single red rectangle ("bad" rectangle).

-You can control you Player Rectangle by using the left and right arrows on your keyboard--these 
buttons will move your rectangle in the respective direction pressed.

-If you hit a single red rectangle, you will lose the game and the letter 'L' will be shown on your screen.
This will signify that you have lost the game.

-If you manage to collect 5 green rectangles consecutively, you will win the game and the letter 'W' will 
be shown on your screen.


