//Text prototypes
void drawChar(int, int, char, unsigned short);
void drawString(int, int, char *, unsigned short);