Instructions for Wings Over Water (from Orisinal):

-The objective of the game is to reach a health that is 250 or more
-The player must move around the screen using the up, down, left, right arrow keys
-The player must collect hearts to increase the bird's health
-Hitting a predatory bird (black bird) will cause the player to lose health
-If the player bird's health reaches zero, the player loses

-Click enter to start the game
-Click enter to transistion to and from the pause and start states