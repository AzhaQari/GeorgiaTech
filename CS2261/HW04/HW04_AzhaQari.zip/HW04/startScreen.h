
//{{BLOCK(startScreen)

//======================================================================
//
//	startScreen, 239x159@8, 
//	+ palette 256 entries, not compressed
//	+ bitmap not compressed
//	Total size: 512 + 38160 = 38672
//
//	Time-stamp: 2020-10-12, 06:35:32
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_STARTSCREEN_H
#define GRIT_STARTSCREEN_H

#define startScreenBitmapLen 38160
extern const unsigned short startScreenBitmap[19080];

#define startScreenPalLen 512
extern const unsigned short startScreenPal[256];

#endif // GRIT_STARTSCREEN_H

//}}BLOCK(startScreen)
