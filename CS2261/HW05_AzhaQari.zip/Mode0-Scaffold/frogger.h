
//{{BLOCK(frogger)

//======================================================================
//
//	frogger, 32x32@4, 
//	+ palette 256 entries, not compressed
//	+ 16 tiles not compressed
//	Total size: 512 + 512 = 1024
//
//	Time-stamp: 2020-10-26, 14:49:40
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_FROGGER_H
#define GRIT_FROGGER_H

#define froggerTilesLen 512
extern const unsigned short froggerTiles[256];

#define froggerPalLen 512
extern const unsigned short froggerPal[256];

#endif // GRIT_FROGGER_H

//}}BLOCK(frogger)
