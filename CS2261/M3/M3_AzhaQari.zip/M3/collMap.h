
//{{BLOCK(collMap)

//======================================================================
//
//	collMap, 240x160@16, 
//	+ bitmap not compressed
//	Total size: 76800 = 76800
//
//	Time-stamp: 2020-11-12, 18:17:48
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_COLLMAP_H
#define GRIT_COLLMAP_H

#define collMapBitmapLen 76800
extern const unsigned short collMapBitmap[38400];

#endif // GRIT_COLLMAP_H

//}}BLOCK(collMap)
