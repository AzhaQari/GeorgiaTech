Kung Flu Instructions (M3)

Use the L/R buttons to move left/right
Use the Up button to jump up 
Dodge the Coronavirus troop (green square); Colliding with a green square will lose you the game

CHEAT: none yet 

There is no win state in this game. Just survive for as long as possible. 
