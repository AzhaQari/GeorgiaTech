Kung Flu Instructions (M2)

Use the L/R buttons to move left/right
Use the Up button to jump up 
Dodge the Coronavirus troop (green square); Colliding with a green square will lose you the game

CHEAT: HOLD DOWN ARROW TO BECOME INVINCIBLE TO RONA TROOPS (i will make this toggle-able)

....No win state has been implemented yet, and I'm having trouble getting my collision map to work.
I plan on coming to office hours to get that fixed 
