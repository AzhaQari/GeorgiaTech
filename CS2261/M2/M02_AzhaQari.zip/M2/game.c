#include <stdlib.h>
#include "myLib.h"
#include "game.h"
#include "splashScreen.h"
#include "pauseScreen.h"
#include "background.h"
#include "winScreen.h"
#include "loseScreen.h"
#include "collMap.h"


// variables
PLAYER player;
RONA rona;
int jumped;
int ground;
int health;
int score;


// initialize the game
void initGame() {
    health = 3;
    jumped = 1;
	initPlayer();
    initRona();
}

// updates game each frame
void updateGame() {
	updatePlayer();
    updateRona();
}

// draws game each frame
void drawGame() {
	drawPlayer();
    drawRona();

}


// initialize player 
void initPlayer() {

	player.row = SHIFTUP(60);
    player.rdel = 0;
	player.col = 20;
	player.cdel = 1;
	player.height = 8;
	player.width = 8;
	player.lives = 3;
}

// update player for every frame
void updatePlayer() {
	
	// controls to move the player bird
	if (BUTTON_HELD(BUTTON_LEFT)
		&& player.col >= 1) {

		player.col -= player.cdel;
	

	} else if (BUTTON_HELD(BUTTON_RIGHT)
		&& player.col + player.width - 1 < SCREENWIDTH - player.cdel) {

		player.col += player.cdel;
	
	} 

    // Gravity implementation
    if (SHIFTDOWN(player.row + player.rdel) < 148) {
        player.row += player.rdel;
    } else {
        player.rdel = 0;
        jumped = 0;
    }

    if (BUTTON_PRESSED(BUTTON_UP) && !jumped) {
        player.rdel -= JUMPPOWER;
        jumped = 1;
    }
    player.rdel += GRAVITY;

    if (BUTTON_HELD(BUTTON_LEFT)) {
        if (player.col > 0 && collMapBitmap[OFFSET(player.col - player.cdel, player.height + player.row - 1, 240)] &&
            collMapBitmap[OFFSET(player.col - player.cdel, player.row, 240)]) {

            player.col -= player.cdel;

        }
    }
    if(BUTTON_HELD(BUTTON_RIGHT)) {
        if (player.col < 240 - player.width && collMapBitmap[OFFSET(player.col + player.cdel + player.width - 1, player.height + player.row - 1, 240)] &&
            collMapBitmap[OFFSET(player.width + player.col + player.cdel - 1, player.row, 240)]) {

            player.col += player.cdel;
        }
    }
}

// draws the player
void drawPlayer() {
	shadowOAM[0].attr0 = ATTR0_SQUARE | (ROWMASK & SHIFTDOWN(player.row));
	shadowOAM[0].attr1 = ATTR1_TINY | (COLMASK & player.col);
	waitForVBlank();
}

void initRona() {
    rona.row = 140;
    rona.rdel = 0;
	rona.col = 230;
	rona.cdel = 1;
	rona.height = 8;
	rona.width = 8;
}

void updateRona() {

    rona.col -= rona.cdel;
    if (rona.col < 0) {
        rona.col += 230;
        rona.row = SHIFTDOWN(player.row) - 8;
    }

    if (!BUTTON_HELD(BUTTON_DOWN) && collision(rona.col, rona.row, rona.width, rona.height, player.col, SHIFTDOWN(player.row), player.width, player.height)) {
        health -= 3;
    }
}

void drawRona() {
    shadowOAM[1].attr0 = ATTR0_SQUARE | (ROWMASK & rona.row);
	shadowOAM[1].attr1 = ATTR1_TINY | (COLMASK & rona.col);
    shadowOAM[1].attr2 = ATTR2_PALROW(0) | ATTR2_TILEID(1, 0);
	waitForVBlank();
}



