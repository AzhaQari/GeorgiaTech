
//{{BLOCK(katamari)

//======================================================================
//
//	katamari, 16x16@8, 
//	+ palette 256 entries, not compressed
//	+ bitmap not compressed
//	Total size: 512 + 256 = 768
//
//	Time-stamp: 2020-10-09, 06:45:33
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_KATAMARI_H
#define GRIT_KATAMARI_H

#define katamariBitmapLen 256
extern const unsigned short katamariBitmap[128];

#define katamariPalLen 512
extern const unsigned short katamariPal[256];

#endif // GRIT_KATAMARI_H

//}}BLOCK(katamari)
