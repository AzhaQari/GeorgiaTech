
//{{BLOCK(treeswithStars)

//======================================================================
//
//	treeswithStars, 512x256@4, 
//	+ palette 256 entries, not compressed
//	+ 357 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 64x32 
//	Total size: 512 + 11424 + 4096 = 16032
//
//	Time-stamp: 2020-10-23, 10:30:31
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_TREESWITHSTARS_H
#define GRIT_TREESWITHSTARS_H

#define treeswithStarsTilesLen 11424
extern const unsigned short treeswithStarsTiles[5712];

#define treeswithStarsMapLen 4096
extern const unsigned short treeswithStarsMap[2048];

#define treeswithStarsPalLen 512
extern const unsigned short treeswithStarsPal[256];

#endif // GRIT_TREESWITHSTARS_H

//}}BLOCK(treeswithStars)
