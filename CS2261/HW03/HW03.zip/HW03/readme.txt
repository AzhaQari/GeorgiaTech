/*
Super Basic Asteroids:
(press enter to start, enter again to pause)

-Try to stay alive for as long as possible
-use arrow keys to move your spaceship around
-red and yellow asteroids will be coming at you from the right.
-click A to shoot the yellow asteroids--red asteroids are indestructable
-don't get hit by an asteroid!

*/